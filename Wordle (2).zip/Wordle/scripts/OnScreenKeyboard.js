import { WordleKey } from "./WordleKey.js";
import { KeyState } from "./Enums.js";
export class OnScreenKeyboard {
    constructor(wordleBoard){
        this.keys = new Map;
        this.wordleBoard = wordleBoard;
        this.newKeyboard();
        this.addEventListeners();
    }

    newKeyboard() {
        const keyElements = document.querySelectorAll('.character');
        keyElements.forEach(keyElement => {
            const letter = keyElement.textContent.trim();
            const wordleKey = new WordleKey(letter, keyElement)
            this.keys.set(letter, wordleKey);
        });
        this.keyCreator('.submit-key');
        this.keyCreator('.delete-key');
    }

    /**
     * Debe ser el elemento del html
     * @param {String} element 
     */
    keyCreator(element) {
        const keyElement = document.querySelector(element);
        const letter = keyElement.textContent.trim();
        const wordleKey = new WordleKey(letter, keyElement);
        this.keys.set(letter, wordleKey);
    }
    
    addEventListeners() {
        this.keys.forEach(key => {
            key.element.addEventListener('click', () => {
                this.handleInput(key.letter);
            });
        });
    }

    handleInput(key) {
        let selectedCell = this.wordleBoard.getSelectedCell();
        if(!selectedCell) return;
        if(key === 'DELETE' || key === '⌫') {
            this.wordleBoard.removeLetter(selectedCell);
        }else if (key === 'SUBMIT' || key === 'ENVIAR') {
            this.wordleBoard.submitWord();
        } else {
            selectedCell.setLetter(key);
            this.wordleBoard.moveSelectionForward();
        }
    }

    lookedKey(keyLetter) {
        const key = this.keys.get(keyLetter);
        if (key) {
            key.updateState(KeyState.LOOKED);
            this.updateKey(key);
        }
    }
    
      resetLookedKey(keyLetter) {
        const key = this.keys.get(keyLetter);
        if (key && key.keyState === KeyState.LOOKED) {
            key.updateState(KeyState.INACTIVE);
            this.updateKey(key);
        }
    }

    getKeys() {
        return this.keys;
    }
}