
export class KeyboardInput {
    constructor(onScreenKeyboard) {
        this.onScreenKeyboard = onScreenKeyboard; 
        this.initializeKeyboardEvents();
    }

    initializeKeyboardEvents() {
        document.addEventListener('keydown', (event) => {
            const key = event.key.toUpperCase();
            this.handleKeyboardInput(event);
        });
    }

    handleKeyboardInput(event) {
        if (event.key.length === 1 && /^[a-zA-ZñÑ]$/.test(event.key)) {
            this.onScreenKeyboard.handleInput(event.key.toUpperCase());
        } else if (event.key === 'Backspace') {
            this.onScreenKeyboard.handleInput('DELETE');
        } else if (event.key === 'Enter') {
            this.onScreenKeyboard.handleInput('SUBMIT');
        }
    }
}