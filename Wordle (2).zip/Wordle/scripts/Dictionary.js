export class Dictionary {
    constructor() {
        this.secretWords = [
            'pasto', 'llave', 'fruta', 'mujer', 'silla', 'cielo', 'plato',
            'lente', 'techo', 'papel', 'lucha', 'grito', 'marzo', 'cerca',
            'campo', 'fuego', 'feliz', 'cerca', 'soler', 'nubes', 'nacer',
            'agua', 'falta', 'algun', 'vocal', 'amigo', 'arbol', 'barra',
            'broma', 'calor', 'canto', 'celda', 'clima', 'comer', 'danza',
            'donde', 'durar', 'exito', 'flaco', 'fluir', 'gente', 'gordo',
            'hueso', 'huevo', 'joven', 'largo', 'libro', 'lindo', 'lleno',
            'mango', 'marca', 'meter', 'miedo', 'mitad', 'movil', 'noche',
            'nuevo', 'niñez', 'pared', 'pasta', 'peces', 'piedra', 'plaza',
            'pluma', 'poeta', 'pulso', 'quien', 'rápido', 'ritmo', 'ruido',
            'salto', 'suave', 'temor', 'tinta', 'torre', 'traje', 'vacas',
            'verde', 'vista', 'voces', 'vuelo', 'yerba', 'zorro', 'zumba',
            'acero', 'aleta', 'ancho', 'antes', 'arena', 'balón', 'bazar',
            'botar', 'burro', 'cable', 'ceder', 'cerca', 'chica', 'creer',
            'darle', 'dedo', 'dieta', 'doble', 'duelo', 'extra', 'fallo',
            'firme', 'girar', 'gusto', 'haber', 'hacha', 'ideal', 'isla',
            'jugar', 'karma', 'lamer', 'lunar', 'mirar', 'nevar', 'niño',
            'oeste', 'oírse', 'óvalo', 'parar', 'pesta', 'pinta', 'puedo',
            'quiso', 'rabia', 'rosal', 'saber', 'secar', 'sirio', 'tenso',
            'tomar', 'ultra', 'uña', 'valle', 'yerno', 'zorro', 'zurdo'
            ];
            this.secretWord = this.getRandomSecretWord();
            this.permittedWords = [
                'abeto', 'abito', 'aguta', 'ancho', 'apelo', 'aviso', 'bache', 'banco', 'basta', 'bebes',
                'bello', 'blusa', 'borde', 'burro', 'cable', 'cacho', 'calor', 'canto', 'carne', 'celda',
                'ciuda', 'coche', 'comas', 'copas', 'cuero', 'dente', 'dudas', 'firme', 'flama', 'fuera',
                'gente', 'grato', 'horro', 'hotel', 'joven', 'lente', 'lugar', 'madre', 'mucho', 'nacer',
                'nieve', 'nunca', 'oruga', 'pacto', 'pasta', 'pedro', 'pinto', 'plato', 'poder', 'quien',
                'rabia', 'reina', 'salud', 'silla', 'soler', 'tabla', 'termo', 'trozo', 'vacan', 'verde',
                'vocal', 'votos', 'yegua', 'yerno', 'zorro', 'zumba', 'pasto', 'llave', 'fruta', 'mujer',
                'cielo', 'papel', 'lucha', 'grito', 'marzo', 'cerca', 'campo', 'fuego', 'feliz', 'nubes',
                'falta', 'amigo', 'arbol', 'barra', 'broma', 'clima', 'comer', 'danza', 'donde', 'durar',
                'exito', 'flaco', 'fluir', 'gordo', 'hueso', 'huevo', 'largo', 'lindo', 'lleno', 'marca',
                'meter', 'miedo', 'mitad', 'movil', 'noche', 'nuevo', 'pared', 'peces', 'piedra', 'plaza',
                'pluma', 'poeta', 'pulso', 'ritmo', 'ruido', 'salto', 'suave', 'temor', 'tinta', 'torre',
                'traje', 'vacas', 'vista', 'voces', 'vuelo', 'yerba', 'acero', 'aleta', 'antes', 'arena',
                'bazar', 'botar', 'ceder', 'chica', 'creer', 'darle', 'dieta', 'doble', 'duelo', 'extra',
                'fallo', 'girar', 'gusto', 'haber', 'hacha', 'ideal', 'jugar', 'karma', 'lamer', 'lunar',
                'mirar', 'nevar', 'parar', 'pesta', 'pinta', 'puedo', 'quiso', 'rosal', 'saber', 'secar',
                'sirio', 'tenso', 'tomar', 'valle', 'zurdo', 'pelea', 'abeja',
                'abran', 'abrir', 'actos', 'adobe', 'ahora', 'aires', 'ajeno', 'alado', 'aldea', 'alero',
                'alfar', 'almas', 'altar', 'alzar', 'amada', 'amiga', 'animo', 'antro', 'apego', 'arena',
                'aroma', 'arpas', 'artes', 'asado', 'asilo', 'astro', 'autor', 'avena', 'avion', 'azote',
                'babel', 'baile', 'bajar', 'banda', 'banjo', 'barco', 'barro', 'bater', 'beber', 'becar',
                'belga', 'berro', 'besos', 'bicho', 'bidon', 'bingo', 'birra', 'bisar', 'bizco', 'bomba',
                'bombo', 'botar', 'bravo', 'breve', 'brisa', 'broma', 'burla', 'buscar', 'cabal', 'cabra',
                'cacao', 'calar', 'calle', 'calza', 'canal', 'caoba', 'capaz', 'cardo', 'carga', 'casar',
                'casco', 'catar', 'causa', 'cavar', 'cegar', 'censo', 'cenar', 'cepo', 'cerco', 'cerdo',
                'cerro', 'cesar', 'chala', 'chile', 'china', 'chino', 'chispa', 'chivo', 'choza', 'chulo',
                'ciclo', 'ciego', 'cifra', 'circo', 'cisne', 'citar', 'clave', 'cloro', 'cobre', 'cobro',
                'cocer', 'codex', 'codon', 'cofre', 'colas', 'colmo', 'comun', 'congo', 'contar', 'coral',
                'corda', 'coser', 'crear', 'credo', 'creer', 'crema', 'criar', 'crudo', 'cuajo', 'cubano',
                'cubre', 'cueva', 'cuota', 'curar', 'curva', 'cutis', 'dalia', 'danza', 'dardo', 'datar',
                'deber', 'debut', 'decir', 'dejar', 'delta', 'denso', 'depor', 'deudo', 'diosa', 'dique',
                'doler', 'donde', 'dorar', 'drama', 'droga', 'ducho', 'dudar', 'dulce', 'dupla', 'durar',
                'ebano', 'edita', 'egipto', 'ejido', 'eldorado', 'elipse', 'elite', 'embarc', 'emisor',
                'emular', 'enana', 'encino', 'enlace', 'entero', 'entida', 'entona', 'enviar', 'envol',
                'epico', 'equipo', 'error', 'escama', 'escoba', 'escuch', 'escurr', 'espada', 'espan',
                'estable', 'estilo', 'etapa', 'eterno', 'evitar', 'examen', 'excusa', 'exigir', 'exilio',
                'exito', 'expand', 'exponer', 'extra', 'fabric', 'fajas', 'falda', 'fallar', 'falso',
                'fango', 'farero', 'farmac', 'fatal', 'febrero', 'felino', 'femar', 'feria', 'fijar',
                'final', 'fiscal', 'fisura', 'flauta', 'flete', 'focos', 'fondo', 'forjar', 'forrar',
                'franja', 'freno', 'frios', 'fruta', 'fuera', 'fuente', 'fuerza', 'furia', 'fusil',
                'gaban', 'gaita', 'ganar', 'garaje', 'garza', 'gemelo', 'gener', 'gestor', 'girar',
                'glosa', 'grava', 'grillo', 'gritar', 'balon', 'penal', 'patea'
            ];
            
    }

    isValidWord(word) {
        const upperCaseWords = this.permittedWords.map(w => w.toUpperCase());
        return upperCaseWords.includes(word);
    }

    getRandomSecretWord() {
        const randomIndex = Math.floor(Math.random() * this.secretWords.length);
        return this.secretWords[randomIndex].toUpperCase();
    }

    getSecretWord(){
        return this.secretWord;
    }

    getSecretWords() {
        return this.secretWords;
    }
}