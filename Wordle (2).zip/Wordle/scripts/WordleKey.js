import { KeyState } from './Enums.js';
export class WordleKey {
    constructor(letter, element){
        this.letter = letter;
        this.keyState = KeyState.UNUSED;
        this.element = element;
    }

    getKey() {
        return this.keyState;
    }

    getLetter() {
        return this.letter;
    }

    updateState(newState) {
        this.keyState = newState;
        this.updateElement();
    }

    getKeyState(){
        return this.keyState;
    }

    updateElement() {
        switch (this.keyState) {
            case KeyState.PERFECT:
                this.element.className = 'perfect-character';
                break;
            case KeyState.RIGHT:
                this.element.className = 'right-character';
                break;
            case KeyState.WRONG:
                this.element.className = 'wrong-character';
                break;
            case KeyState.LOOKED:
                this.element.className = 'looked-character';
                break;
            default:
                this.element.className = 'inactive-character';
                break;
        }
    }
}