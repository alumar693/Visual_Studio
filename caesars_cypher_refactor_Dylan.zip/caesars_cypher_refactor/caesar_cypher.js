/*
Explicación de los cambios que he hecho:
- He arreglado la operación de la función de descifrado para que haga el descifrado correctamente en caso de que al mover la letra se salga de rango.
- He reorganizado los cálculos de las funciones de cifrado y descifrado en una sola función para evitar repetir código.
- He cambiado los nombres de las variables y las funciones para que se entienda mejor para que sirven y así mejorar la legibilidad del código.
- He cambiado las funciones de comprobación de letras mayúsculas y minúsculas en una sola de mayúsculas en la que cambio la letra a mayúscula siempre ya que la comprobación era la misma y servía para lo mismo,
  así ahorro código.

No he tocado tema de clases porque a parte de no verlo extrictamente necesario, no he dado JS y no sabría hacerlo, he pensado que podría tener una clase padre cifrado cesar o algo asi con el alfabeto
y las funciones de calculo y comprobación y después clases cifrar y descifrar que hereden de esta y utilicen y quizas sobreescriban el método de cifrado, pero al no tener la necesidad de crear ningún objeto
ni de tener ningún atributo veo mejor algo mas simple como es tenerlo todo en un archivo y simplemente usar la función que necesites.
Si consideras mejor crear clases dímelo en la corrección, aprendo a hacerlo y lo hago, gracias.
*/
const ALPHABET_LENGTH = 26;
const LETTERS_OF_THE_ALPHABET = {A: 65, Z: 90}

function letterGoesOutAlphabete(letter, displacement){
  return letter + "".toUpperCase >= LETTERS_OF_THE_ALPHABET.A && letter <= LETTERS_OF_THE_ALPHABET.Z && (letter + displacement > LETTERS_OF_THE_ALPHABET.Z||letter+displacement < LETTERS_OF_THE_ALPHABET.A);
}

function cipherCalculation(textToCipher, displacement) {
  let ciphertext = '';
  let newLetter, displacementToApply, currentLetter;
  let cipherOrDecipher = displacement > 0? displacement - ALPHABET_LENGTH : displacement + ALPHABET_LENGTH; 
  for (let i = 0; i < textToCipher.length; i++) {
    currentLetter = textToCipher.charCodeAt(i);
    displacementToApply = letterGoesOutAlphabete(currentLetter, displacement)?cipherOrDecipher:displacement;    
    newLetter = String.fromCharCode(currentLetter + displacementToApply);
    ciphertext = ciphertext.concat(newLetter);
  }
  return ciphertext;
}


function cipher(textToCipher, displacement) {   
  displacement = displacement % ALPHABET_LENGTH;
  return cipherCalculation(textToCipher, displacement);
}
  
function decipher(textToDecipher, displacement) {
  displacement = -displacement % ALPHABET_LENGTH;
  return cipherCalculation(textToDecipher, displacement);
}
  
console.assert(
  cipher('Hello World', 1) === 'Ifmmp!Xpsme',
  `${cipher('Hello World', 1)} === 'Ifmmp!Xpsme'`,
);
console.assert(
  decipher(cipher('Hello World', 3), 3) === 'Hello World',
  `${decipher(cipher('Hello World', 3), 3)} === 'Hello World'`,
);